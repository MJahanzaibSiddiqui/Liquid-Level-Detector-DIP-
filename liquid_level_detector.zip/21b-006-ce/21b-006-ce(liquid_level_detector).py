import cv2
import numpy as np
import tkinter as tk
from tkinter import filedialog, Label, Button, Canvas
from PIL import Image, ImageTk

def upload_image():
    global uploaded_image, uploaded_image_cv, threshold_image_cv, liquid_result_label
    
    # Open file dialog to upload an image
    file_path = filedialog.askopenfilename()
    if not file_path:
        return
    
    # Load and process the image using OpenCV
    uploaded_image_cv = cv2.imread(file_path)
    uploaded_image_cv = cv2.resize(uploaded_image_cv, (200, 400))  # Resize for uniformity
    grayscale = cv2.cvtColor(uploaded_image_cv, cv2.COLOR_BGR2GRAY)
    _, threshold_image_cv = cv2.threshold(grayscale, 100, 255, cv2.THRESH_BINARY_INV)
    
    # Detect the liquid level
    liquid_level = detect_liquid_level(threshold_image_cv)
    
    # Update GUI with images and results
    display_image(uploaded_image_cv, canvas_uploaded)
    display_image(threshold_image_cv, canvas_threshold, is_binary=True)
    liquid_result_label.config(text=f"Liquid Level: {liquid_level}")

def detect_liquid_level(binary_image):
    # Calculate the total height and liquid height
    height, width = binary_image.shape
    total_height = height
    liquid_height = np.sum(np.any(binary_image == 255, axis=1))
    
    # Calculate fill percentage
    fill_percentage = (liquid_height / total_height) * 100
    
    # Classify liquid levels
    if fill_percentage < 5:
        return "Empty"
    elif fill_percentage < 25:
        return "Quarter"
    elif fill_percentage < 50:
        return "Half"
    elif fill_percentage < 75:
        return "Three-Quarters"
    else:
        return "Full"

def display_image(image, canvas, is_binary=False):
    # Convert image for display in Tkinter
    if is_binary:
        image_pil = Image.fromarray(image)  # Binary image is already grayscale
    else:
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        image_pil = Image.fromarray(image_rgb)
    
    image_tk = ImageTk.PhotoImage(image_pil)
    canvas.config(width=image_pil.width, height=image_pil.height)
    canvas.create_image(0, 0, anchor='nw', image=image_tk)
    canvas.image = image_tk  # Prevent garbage collection

# GUI Setup
root = tk.Tk()
root.title("Liquid Level Detection System")
root.configure(bg='#2E2E2E')

# Upload Button
upload_button = Button(root, text="Upload Image", command=upload_image, bg='#4CAF50', fg='white',
                       font=('Arial', 14, 'bold'), relief='flat', padx=10, pady=5)
upload_button.grid(row=0, column=0, columnspan=3, pady=10)

# Labels
Label(root, text="Uploaded Image", bg='#2E2E2E', fg='white', font=('Arial', 12, 'bold')).grid(row=1, column=0)
Label(root, text="Threshold Image", bg='#2E2E2E', fg='white', font=('Arial', 12, 'bold')).grid(row=1, column=1)
# Label(root, text="Liquid Level Detection", bg='#2E2E2E', fg='white', font=('Arial', 12, 'bold')).grid(row=1, column=2)

# Canvases for Images
canvas_uploaded = Canvas(root, width=200, height=400, bg='black')
canvas_uploaded.grid(row=2, column=0, padx=10)
canvas_threshold = Canvas(root, width=200, height=400, bg='black')
canvas_threshold.grid(row=2, column=1, padx=10)
# canvas_detected = Canvas(root, width=200, height=400, bg='black')
# canvas_detected.grid(row=2, column=2, padx=10)

# Liquid Result Label
liquid_result_label = Label(root, text="Liquid Level: Not Detected", bg='#2E2E2E', fg='white',
                            font=('Arial', 14, 'bold'))
liquid_result_label.grid(row=3, column=0, columnspan=3, pady=10)

root.mainloop()
